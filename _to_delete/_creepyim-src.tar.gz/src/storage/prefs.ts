import AsyncStorage from '@react-native-async-storage/async-storage';

const ONBOARDING_KEY = 'creepyim.onboarding.completed.v1';

/**
 * Onboarding completion is a plain preference, not a secret, so AsyncStorage
 * is correct here. Auth tokens (screen 3, later) belong in expo-secure-store
 * instead — see src/auth/session.ts.
 */
export async function hasCompletedOnboarding(): Promise<boolean> {
  try {
    return (await AsyncStorage.getItem(ONBOARDING_KEY)) === 'true';
  } catch {
    // A storage failure must not lock the user out of the app; showing
    // onboarding again is the harmless direction to fail in.
    return false;
  }
}

export async function setOnboardingComplete(): Promise<void> {
  try {
    await AsyncStorage.setItem(ONBOARDING_KEY, 'true');
  } catch {
    // Non-fatal: worst case the user sees onboarding once more.
  }
}

export async function resetOnboarding(): Promise<void> {
  try {
    await AsyncStorage.removeItem(ONBOARDING_KEY);
  } catch {
    // Non-fatal.
  }
}
