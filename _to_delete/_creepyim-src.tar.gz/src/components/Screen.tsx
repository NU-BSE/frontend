import React from 'react';
import { StyleSheet, View, type ViewProps } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import { palette, spacing } from '@/theme/tokens';

export interface ScreenProps extends ViewProps {
  /** Adds horizontal gutters. Off for full-bleed lists. */
  padded?: boolean;
  /** Respects the status-bar inset. Off when a header already does. */
  topInset?: boolean;
  /** Respects the gesture-bar inset. Off when a tab bar already does. */
  bottomInset?: boolean;
}

/**
 * Root container for every screen.
 *
 * Owns background colour and safe-area insets so no screen re-derives them.
 * Android edge-to-edge is enabled app-wide, which makes explicit inset
 * handling mandatory rather than optional.
 */
export function Screen({
  padded = true,
  topInset = true,
  bottomInset = false,
  style,
  ...rest
}: ScreenProps) {
  const insets = useSafeAreaInsets();

  return (
    <View
      {...rest}
      style={[
        styles.root,
        padded && styles.padded,
        topInset && { paddingTop: insets.top },
        bottomInset && { paddingBottom: insets.bottom },
        style,
      ]}
    />
  );
}

const styles = StyleSheet.create({
  root: {
    flex: 1,
    backgroundColor: palette.void,
  },
  padded: {
    paddingHorizontal: spacing.lg,
  },
});
