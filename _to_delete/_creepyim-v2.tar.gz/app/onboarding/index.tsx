import React, { useCallback, useState } from 'react';
import { useRouter } from 'expo-router';
import { Image, Pressable, ScrollView, StyleSheet, View } from 'react-native';

import { Icon } from '@/components/Icon';
import { OnboardingNavBar } from '@/components/OnboardingNavBar';
import { Screen } from '@/components/Screen';
import { Text } from '@/components/Text';
import { SCENARIOS, type ScenarioId } from '@/features/scenarios/registry';
import { setSelectedCategories } from '@/storage/prefs';
import { gutter, palette, radius, shadow, spacing } from '@/theme/tokens';

const MASCOT = require('@assets/creepy-mascot.png');

/** Figma: 2 columns, 16px gutter, inside a 24px page margin on a 390pt frame. */
const COLUMN_GAP = spacing.lg;

export default function OnboardingCategories() {
  const router = useRouter();
  const [selected, setSelected] = useState<ScenarioId[]>([]);

  const toggle = useCallback((id: ScenarioId) => {
    setSelected((current) =>
      current.includes(id)
        ? current.filter((existing) => existing !== id)
        : [...current, id],
    );
  }, []);

  const advance = useCallback(async () => {
    await setSelectedCategories(selected);
    router.push('/onboarding/memory');
  }, [router, selected]);

  return (
    <Screen>
      <ScrollView
        contentContainerStyle={styles.content}
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.intro}>
          <View style={styles.mascotFrame}>
            <Image source={MASCOT} style={styles.mascot} resizeMode="cover" />
          </View>

          <Text variant="headline" style={styles.heading}>
            Where do you need support most?
          </Text>
          <Text variant="bodyLarge" tone="secondary" style={styles.body}>
            Select the categories you&apos;ll use most frequently to help Creepy
            optimize your experience.
          </Text>
        </View>

        <View style={styles.grid}>
          {SCENARIOS.map((scenario) => {
            const active = selected.includes(scenario.id);
            return (
              <Pressable
                key={scenario.id}
                accessibilityRole="checkbox"
                accessibilityState={{ checked: active }}
                accessibilityLabel={scenario.title}
                onPress={() => toggle(scenario.id)}
                style={({ pressed }) => [
                  styles.cell,
                  active && styles.cellActive,
                  pressed && styles.pressed,
                ]}
              >
                <Icon
                  source={scenario.Icon}
                  size={30}
                  color={active ? palette.brand : palette.textSecondary}
                />
                <Text
                  variant="label"
                  tone={active ? 'brand' : 'primary'}
                  style={styles.cellLabel}
                >
                  {scenario.title}
                </Text>
              </Pressable>
            );
          })}
        </View>
      </ScrollView>

      <OnboardingNavBar
        onAdvance={() => void advance()}
        advanceLabel="Continue"
        // Skipping is allowed: an empty selection is a valid answer, and
        // blocking here would trap anyone who genuinely wants everything.
      />
    </Screen>
  );
}

const styles = StyleSheet.create({
  content: {
    paddingHorizontal: gutter.screen,
    paddingTop: spacing.xxl,
    paddingBottom: spacing.xxl,
  },
  intro: { alignItems: 'center', paddingBottom: spacing.xxxl },
  mascotFrame: {
    width: 96,
    height: 96,
    borderRadius: radius.lg,
    borderWidth: 1,
    borderColor: palette.borderFaint,
    overflow: 'hidden',
    marginBottom: spacing.xxl,
    ...shadow.card,
  },
  mascot: { width: '100%', height: '100%' },
  heading: { textAlign: 'center', marginBottom: spacing.lg },
  body: { textAlign: 'center' },
  grid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: COLUMN_GAP,
  },
  cell: {
    // Two per row: half the available width minus half the gap.
    width: `${50}%`,
    flexGrow: 1,
    flexBasis: `${48}%`,
    maxWidth: `${48.5}%`,
    minHeight: 144,
    alignItems: 'center',
    justifyContent: 'center',
    gap: spacing.lg,
    paddingHorizontal: spacing.lg,
    backgroundColor: palette.surface,
    borderWidth: 1,
    borderColor: palette.borderSoft,
    borderRadius: radius.md,
  },
  cellActive: { borderColor: palette.brand, backgroundColor: palette.brandWash },
  cellLabel: { textAlign: 'center' },
  pressed: { opacity: 0.8 },
});
