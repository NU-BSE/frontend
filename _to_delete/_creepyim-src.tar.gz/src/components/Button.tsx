import React from 'react';
import {
  ActivityIndicator,
  Pressable,
  StyleSheet,
  View,
  type PressableProps,
} from 'react-native';

import { Text } from './Text';
import { MIN_TOUCH_TARGET, palette, radius, spacing } from '@/theme/tokens';

type Variant = 'primary' | 'secondary' | 'ghost';

export interface ButtonProps extends Omit<PressableProps, 'children'> {
  label: string;
  variant?: Variant;
  loading?: boolean;
  /** Rendered before the label — auth provider marks, mostly. */
  leading?: React.ReactNode;
  fullWidth?: boolean;
}

export function Button({
  label,
  variant = 'primary',
  loading = false,
  leading,
  fullWidth = true,
  disabled,
  style,
  ...rest
}: ButtonProps) {
  const isDisabled = Boolean(disabled) || loading;

  return (
    <Pressable
      accessibilityRole="button"
      accessibilityState={{ disabled: isDisabled, busy: loading }}
      disabled={isDisabled}
      style={(state) => [
        styles.base,
        VARIANT_STYLE[variant],
        fullWidth && styles.fullWidth,
        state.pressed && styles.pressed,
        isDisabled && styles.disabled,
        typeof style === 'function' ? style(state) : style,
      ]}
      {...rest}
    >
      <View style={styles.content}>
        {loading ? (
          <ActivityIndicator
            size="small"
            color={variant === 'primary' ? palette.textPrimary : palette.accent}
          />
        ) : (
          <>
            {leading ? <View style={styles.leading}>{leading}</View> : null}
            <Text
              variant="heading"
              tone={variant === 'primary' ? 'primary' : 'secondary'}
            >
              {label}
            </Text>
          </>
        )}
      </View>
    </Pressable>
  );
}

const VARIANT_STYLE: Record<Variant, object> = {
  primary: { backgroundColor: palette.accent },
  secondary: {
    backgroundColor: palette.surfaceRaised,
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: palette.hairline,
  },
  ghost: { backgroundColor: 'transparent' },
};

const styles = StyleSheet.create({
  base: {
    minHeight: MIN_TOUCH_TARGET,
    borderRadius: radius.md,
    paddingHorizontal: spacing.lg,
    justifyContent: 'center',
    alignItems: 'center',
  },
  fullWidth: { alignSelf: 'stretch' },
  content: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
  },
  leading: { justifyContent: 'center' },
  pressed: { opacity: 0.75 },
  disabled: { opacity: 0.45 },
});
