/**
 * Design tokens.
 *
 * PLACEHOLDER VALUES — these are a structurally-correct scaffold, not the
 * Creepy.IM palette. They get replaced wholesale from the Figma file's
 * published variables (`get_variable_defs`). Screens must only ever read
 * from this module, never hardcode a hex or a magic number, so that swap is
 * a one-file change.
 */

export const palette = {
  void: '#07070A',
  surface: '#101016',
  surfaceRaised: '#17171F',
  hairline: '#24242E',
  textPrimary: '#EDEDF2',
  textSecondary: '#9A9AA8',
  textMuted: '#5E5E6E',
  accent: '#7C3AED',
  accentMuted: '#4C2889',
  danger: '#E5484D',
  success: '#46A758',
} as const;

/** 4pt grid. Every margin/padding in the app resolves to one of these. */
export const spacing = {
  xs: 4,
  sm: 8,
  md: 12,
  lg: 16,
  xl: 24,
  xxl: 32,
  xxxl: 48,
} as const;

export const radius = {
  sm: 6,
  md: 10,
  lg: 16,
  xl: 24,
  pill: 999,
} as const;

export const typography = {
  display: { fontSize: 32, lineHeight: 38, fontWeight: '700' },
  title: { fontSize: 22, lineHeight: 28, fontWeight: '600' },
  heading: { fontSize: 17, lineHeight: 24, fontWeight: '600' },
  body: { fontSize: 15, lineHeight: 22, fontWeight: '400' },
  caption: { fontSize: 13, lineHeight: 18, fontWeight: '400' },
  micro: { fontSize: 11, lineHeight: 14, fontWeight: '500' },
} as const;

/**
 * Android's minimum comfortable touch target. Anything interactive must meet
 * this, via size or via `hitSlop`.
 */
export const MIN_TOUCH_TARGET = 48;

export type Spacing = keyof typeof spacing;
export type Radius = keyof typeof radius;
export type TypographyVariant = keyof typeof typography;
