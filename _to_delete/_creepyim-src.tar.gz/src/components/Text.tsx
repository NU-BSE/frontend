import React from 'react';
import { StyleSheet, Text as RNText, type TextProps } from 'react-native';

import { palette, typography, type TypographyVariant } from '@/theme/tokens';

type Tone = 'primary' | 'secondary' | 'muted' | 'accent' | 'danger';

const TONE_COLOR: Record<Tone, string> = {
  primary: palette.textPrimary,
  secondary: palette.textSecondary,
  muted: palette.textMuted,
  accent: palette.accent,
  danger: palette.danger,
};

export interface AppTextProps extends TextProps {
  variant?: TypographyVariant;
  tone?: Tone;
}

/**
 * The only text primitive in the app.
 *
 * Funnelling every string through one component is what keeps type scale and
 * colour consistent once the real Figma tokens land — no screen owns a
 * fontSize.
 */
export function Text({
  variant = 'body',
  tone = 'primary',
  style,
  ...rest
}: AppTextProps) {
  return (
    <RNText
      {...rest}
      style={[
        styles.base,
        typography[variant] as object,
        { color: TONE_COLOR[tone] },
        style,
      ]}
    />
  );
}

const styles = StyleSheet.create({
  base: {
    // Android renders tighter than iOS at the same metrics; included so the
    // Figma line-height values map predictably.
    includeFontPadding: false,
  },
});
