import React, { useCallback, useEffect, useMemo, useRef } from 'react';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import {
  FlatList,
  KeyboardAvoidingView,
  Platform,
  StyleSheet,
  View,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import type { UIMessage } from '@tanstack/ai/client';

import { Screen } from '@/components/Screen';
import { Text } from '@/components/Text';
import { useCreepyChat } from '@/ai/useCreepyChat';
import { Composer } from '@/features/feed/Composer';
import { MessageBubble, messageText } from '@/features/feed/MessageBubble';
import { appendHistory } from '@/storage/history';
import { palette, spacing } from '@/theme/tokens';

const ORIGIN_LABEL = {
  'on-device': 'Running on this device',
  remote: 'Running on a server',
  stub: 'Offline preview',
} as const;

export default function Feed() {
  const insets = useSafeAreaInsets();
  const queryClient = useQueryClient();
  const listRef = useRef<FlatList<UIMessage>>(null);

  const {
    messages,
    sendMessage,
    stop,
    isLoading,
    error,
    engineOrigin,
    engineStatus,
    degradedReason,
  } = useCreepyChat();

  const save = useMutation({
    mutationFn: appendHistory,
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['history'] }),
  });

  // Persist each completed exchange exactly once. Keyed on message id so a
  // re-render during streaming cannot write a partial reply.
  const savedIds = useRef(new Set<string>());
  useEffect(() => {
    if (isLoading) return;
    const last = messages[messages.length - 1];
    if (!last || last.role !== 'assistant') return;
    if (savedIds.current.has(last.id)) return;

    const reply = messageText(last).trim();
    if (!reply) return;

    const prompt = [...messages]
      .reverse()
      .find((m) => m.role === 'user');

    savedIds.current.add(last.id);
    save.mutate({
      threadId: last.id,
      prompt: prompt ? messageText(prompt) : '',
      reply,
      engine: engineOrigin,
    });
  }, [engineOrigin, isLoading, messages, save]);

  const scrollToEnd = useCallback(() => {
    listRef.current?.scrollToEnd({ animated: true });
  }, []);

  const handleSend = useCallback(
    (text: string) => {
      void sendMessage(text);
      // Scroll after the user's own bubble mounts, not before.
      requestAnimationFrame(scrollToEnd);
    },
    [scrollToEnd, sendMessage],
  );

  const statusLine = useMemo(() => {
    if (engineStatus === 'preparing') return 'Waking up…';
    if (engineStatus === 'degraded') {
      return degradedReason ?? 'Fell back to offline preview';
    }
    return ORIGIN_LABEL[engineOrigin];
  }, [degradedReason, engineOrigin, engineStatus]);

  return (
    <Screen padded={false}>
      <View style={styles.header}>
        <Text variant="title">Feed</Text>
        <Text
          variant="micro"
          tone={engineStatus === 'degraded' ? 'danger' : 'muted'}
        >
          {statusLine}
        </Text>
      </View>

      <KeyboardAvoidingView
        style={styles.flex}
        behavior={Platform.OS === 'ios' ? 'padding' : undefined}
        keyboardVerticalOffset={insets.top}
      >
        <FlatList
          ref={listRef}
          data={messages}
          keyExtractor={(message) => message.id}
          contentContainerStyle={styles.listContent}
          onContentSizeChange={scrollToEnd}
          keyboardShouldPersistTaps="handled"
          renderItem={({ item, index }) => (
            <MessageBubble
              message={item}
              streaming={
                isLoading &&
                index === messages.length - 1 &&
                item.role === 'assistant'
              }
            />
          )}
          ListEmptyComponent={
            <View style={styles.empty}>
              <Text variant="body" tone="muted" style={styles.emptyText}>
                Nothing here yet. It is still worth being careful what you say.
              </Text>
            </View>
          }
        />

        {error ? (
          <View style={styles.error}>
            <Text variant="caption" tone="danger">
              {error.message}
            </Text>
          </View>
        ) : null}

        <View style={{ paddingBottom: insets.bottom }}>
          <Composer
            onSend={handleSend}
            onStop={stop}
            busy={isLoading}
            disabled={engineStatus === 'preparing'}
          />
        </View>
      </KeyboardAvoidingView>
    </Screen>
  );
}

const styles = StyleSheet.create({
  flex: { flex: 1 },
  header: {
    paddingHorizontal: spacing.lg,
    paddingBottom: spacing.md,
    gap: spacing.xs,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: palette.hairline,
  },
  listContent: {
    padding: spacing.lg,
    flexGrow: 1,
  },
  empty: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: spacing.xl,
  },
  emptyText: { textAlign: 'center' },
  error: {
    paddingHorizontal: spacing.lg,
    paddingBottom: spacing.sm,
  },
});
