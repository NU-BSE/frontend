import React, { useCallback, useRef, useState } from 'react';
import { useQueryClient } from '@tanstack/react-query';
import { useRouter } from 'expo-router';
import {
  FlatList,
  StyleSheet,
  useWindowDimensions,
  View,
  type NativeScrollEvent,
  type NativeSyntheticEvent,
} from 'react-native';

import { Button } from '@/components/Button';
import { Screen } from '@/components/Screen';
import { Text } from '@/components/Text';
import {
  ONBOARDING_SLIDES,
  type OnboardingSlide,
} from '@/features/onboarding/slides';
import { setOnboardingComplete } from '@/storage/prefs';
import { palette, radius, spacing } from '@/theme/tokens';

export default function Onboarding() {
  const router = useRouter();
  const queryClient = useQueryClient();
  const { width } = useWindowDimensions();
  const listRef = useRef<FlatList<OnboardingSlide>>(null);
  const [index, setIndex] = useState(0);

  const isLast = index === ONBOARDING_SLIDES.length - 1;

  const onScroll = useCallback(
    (event: NativeSyntheticEvent<NativeScrollEvent>) => {
      const next = Math.round(event.nativeEvent.contentOffset.x / width);
      // Guard: momentum scroll fires many events; only commit real changes.
      setIndex((current) => (current === next ? current : next));
    },
    [width],
  );

  const finish = useCallback(async () => {
    await setOnboardingComplete();
    // The gate reads this through Query; invalidating keeps the two in sync
    // rather than relying on a remount.
    await queryClient.invalidateQueries({ queryKey: ['onboarding-status'] });
    router.replace('/(tabs)/feed');
  }, [queryClient, router]);

  const advance = useCallback(() => {
    if (isLast) {
      void finish();
      return;
    }
    listRef.current?.scrollToOffset({
      offset: (index + 1) * width,
      animated: true,
    });
  }, [finish, index, isLast, width]);

  return (
    <Screen padded={false} bottomInset>
      <FlatList
        ref={listRef}
        data={ONBOARDING_SLIDES}
        keyExtractor={(slide) => slide.id}
        horizontal
        pagingEnabled
        showsHorizontalScrollIndicator={false}
        onScroll={onScroll}
        scrollEventThrottle={16}
        // Fixed page width means offsets are exact — no measurement pass.
        getItemLayout={(_, i) => ({ length: width, offset: width * i, index: i })}
        renderItem={({ item }) => (
          <View style={[styles.slide, { width }]}>
            <View style={styles.art} />
            <Text variant="display" style={styles.title}>
              {item.title}
            </Text>
            <Text variant="body" tone="secondary" style={styles.body}>
              {item.body}
            </Text>
          </View>
        )}
      />

      <View style={styles.footer}>
        <View
          style={styles.dots}
          accessibilityRole="progressbar"
          accessibilityValue={{
            min: 1,
            max: ONBOARDING_SLIDES.length,
            now: index + 1,
          }}
        >
          {ONBOARDING_SLIDES.map((slide, i) => (
            <View
              key={slide.id}
              style={[styles.dot, i === index && styles.dotActive]}
            />
          ))}
        </View>

        <Button label={isLast ? 'Enter' : 'Next'} onPress={advance} />
        {!isLast ? (
          <Button label="Skip" variant="ghost" onPress={() => void finish()} />
        ) : (
          // Reserves the same height so the primary button does not jump on
          // the last slide.
          <View style={styles.footerSpacer} />
        )}
      </View>
    </Screen>
  );
}

const styles = StyleSheet.create({
  slide: {
    flex: 1,
    paddingHorizontal: spacing.xl,
    justifyContent: 'center',
  },
  art: {
    height: 220,
    borderRadius: radius.xl,
    backgroundColor: palette.surface,
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: palette.hairline,
    marginBottom: spacing.xxl,
  },
  title: { marginBottom: spacing.md },
  body: { maxWidth: 340 },
  footer: {
    paddingHorizontal: spacing.xl,
    paddingBottom: spacing.lg,
    gap: spacing.md,
  },
  dots: {
    flexDirection: 'row',
    justifyContent: 'center',
    gap: spacing.sm,
    paddingVertical: spacing.lg,
  },
  dot: {
    width: 6,
    height: 6,
    borderRadius: radius.pill,
    backgroundColor: palette.hairline,
  },
  dotActive: { backgroundColor: palette.accent, width: 20 },
  footerSpacer: { height: 48 },
});
