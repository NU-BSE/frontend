# Creepy.IM — Android frontend

Expo (SDK 57) + Expo Router + TanStack Query + TanStack AI. Android only.

## Status

| Area | State |
| --- | --- |
| Navigation, providers, storage | Done |
| AI layer (swappable engine) | Done, verified against a real `ChatClient` |
| Onboarding, Feed, History, Account | Built and bundling — **styled with placeholder tokens** |
| Figma visual pass | **Pending the design file** |
| Auth providers (Telegram/Google/Facebook) | Registry in place, integrations stubbed |

Everything compiles: `tsc` clean, `expo-doctor` 20/20, Android bundle exports.

## Run

```bash
npm install --legacy-peer-deps   # see "Known npm quirk" below
cp .env.example .env
npm run android
```

Verification:

```bash
npm run typecheck
npm run verify:ai   # drives the real ChatClient through the custom connection
```

## The AI architecture

The brief asked for an on-device model *through* TanStack AI. Those are not in
tension, because TanStack AI splits into two halves:

```
UI  ──►  useChat (@tanstack/ai-react)  ──►  ConnectionAdapter  ──►  engine
                    │                              │
        screens only ever see this      this is the swappable part
```

`ConnectionAdapter` is normally an HTTP transport to a server. TanStack AI
also exports `stream(factory)`, which accepts any `AsyncIterable<StreamChunk>` —
the documented seam for non-HTTP transports. `src/ai/engineConnection.ts` uses
it to run inference **in-process** and emit a protocol-correct AG-UI event
stream:

```
RUN_STARTED → TEXT_MESSAGE_START → TEXT_MESSAGE_CONTENT×N → TEXT_MESSAGE_END → RUN_FINISHED
```

Consequences worth knowing:

- No server, no network, no API key is required for the app to work.
- Screens are engine-agnostic. Moving to a hosted model later is a change in
  `resolveEngine()`, not in any screen.
- `npm run verify:ai` drives a real `ChatClient` through this connection and
  asserts the message actually assembles and the loading state resolves. A
  hand-built event stream can look right and still hang the client; that
  script is what rules it out.

### Engines

| Engine | File | When it runs |
| --- | --- | --- |
| On-device | `src/ai/engines/onDeviceEngine.ts` | `EXPO_PUBLIC_LLM_MODEL_PATH` set **and** `llama.rn` present |
| Offline preview | `src/ai/engines/stubEngine.ts` | Fallback, and the default in Expo Go |
| Remote | TanStack AI's `xhrHttpStream` | Only when `EXPO_PUBLIC_LLM_ENGINE=remote` |

`llama.rn` is imported lazily inside a `try/catch`. That is deliberate: it is a
native module that does not exist in Expo Go or before `expo prebuild`, and a
static import would crash the bundle for anyone who has not built yet. Absence
is reported as unavailability, and `AiProvider` degrades to the preview engine
with a visible reason rather than leaving a chat box that silently never
answers.

### Enabling real on-device inference

```bash
npm install llama.rn
npx expo prebuild --platform android   # llama.rn needs a dev build
# push a GGUF to the device, then set EXPO_PUBLIC_LLM_MODEL_PATH
```

Start with a small quantised model (1–3B, Q4_K_M). `n_gpu_layers` defaults to 0
in `src/ai/config.ts` because GPU offload is inconsistent across Android GPUs.

## Layout

```
app/                      Expo Router routes
  _layout.tsx             Providers: GestureHandler → SafeArea → Query → Ai
  index.tsx               Gate: onboarding vs feed
  onboarding/index.tsx    Three-slide pager
  (tabs)/feed.tsx         Chat feed, streams from the local engine
  (tabs)/history.tsx      On-device history, TanStack Query backed
  (tabs)/account.tsx      Screen 3 — auth provider slots + model status
src/
  ai/                     Engines, connection adapter, provider, hook
  components/             Text, Screen, Button — the only style primitives
  features/               Screen-specific pieces
  storage/                AsyncStorage repositories
  auth/providers.ts       Provider registry for the Telegram/Google/FB work
  theme/tokens.ts         ← replaced wholesale from Figma
```

## What is deliberately not done yet

**Visual design.** `src/theme/tokens.ts` holds structurally-correct placeholder
values, not the Creepy.IM palette. Every screen reads from it and no screen
hardcodes a hex or a font size, so applying the real design is a token swap
plus per-screen layout adjustment — not a rewrite. Send the Figma file and this
becomes a mechanical pass.

**Auth.** `src/auth/providers.ts` defines the provider shape; buttons render
disabled with the reason. Implementing one means writing `signIn` and flipping
`enabled`. Tokens go in `expo-secure-store` (already installed), never
AsyncStorage.

## Known npm quirk

`expo-router` pulls web-only deps (`vaul` → `react-dom@19.2.8`) whose peer range
does not match the `react@19.2.3` Expo pins. It is irrelevant to an Android-only
app but blocks a strict `npm install`. Use `--legacy-peer-deps`.
