import React from 'react';
import { Tabs } from 'expo-router';
import { StyleSheet } from 'react-native';

import { palette, spacing, typography } from '@/theme/tokens';

export default function TabsLayout() {
  return (
    <Tabs
      screenOptions={{
        headerShown: false,
        sceneStyle: { backgroundColor: palette.void },
        tabBarStyle: styles.bar,
        tabBarActiveTintColor: palette.accent,
        tabBarInactiveTintColor: palette.textMuted,
        tabBarLabelStyle: styles.label,
        // Icons land with the Figma asset export; labels alone are legible
        // and keep the bar honest until then.
        tabBarIconStyle: { display: 'none' },
      }}
    >
      <Tabs.Screen name="feed" options={{ title: 'Feed' }} />
      <Tabs.Screen name="history" options={{ title: 'History' }} />
      <Tabs.Screen name="account" options={{ title: 'Account' }} />
    </Tabs>
  );
}

const styles = StyleSheet.create({
  bar: {
    backgroundColor: palette.surface,
    borderTopColor: palette.hairline,
    borderTopWidth: StyleSheet.hairlineWidth,
    paddingTop: spacing.sm,
    height: 64,
  },
  label: {
    ...typography.micro,
    marginBottom: spacing.sm,
  },
});
