import React, { useCallback } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { ActivityIndicator, FlatList, Pressable, StyleSheet, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import { Screen } from '@/components/Screen';
import { Text } from '@/components/Text';
import { clearHistory, listHistory, type HistoryEntry } from '@/storage/history';
import { palette, radius, spacing } from '@/theme/tokens';

/** Relative time without pulling in a date library — the only granularities
 *  this list needs are "just now" through "N days ago". */
function relativeTime(epochMs: number): string {
  const seconds = Math.max(0, Math.floor((Date.now() - epochMs) / 1000));
  if (seconds < 60) return 'just now';
  const minutes = Math.floor(seconds / 60);
  if (minutes < 60) return `${minutes}m ago`;
  const hours = Math.floor(minutes / 60);
  if (hours < 24) return `${hours}h ago`;
  const days = Math.floor(hours / 24);
  return `${days}d ago`;
}

function HistoryRow({ entry }: { entry: HistoryEntry }) {
  return (
    <Pressable
      accessibilityRole="button"
      accessibilityLabel={`Exchange from ${relativeTime(entry.createdAt)}`}
      style={({ pressed }) => [styles.row, pressed && styles.rowPressed]}
    >
      <View style={styles.rowHeader}>
        <Text variant="micro" tone="muted">
          {relativeTime(entry.createdAt)}
        </Text>
        <Text variant="micro" tone={entry.engine === 'on-device' ? 'accent' : 'muted'}>
          {entry.engine}
        </Text>
      </View>

      {entry.prompt ? (
        <Text variant="caption" tone="muted" numberOfLines={1}>
          you: {entry.prompt}
        </Text>
      ) : null}

      <Text variant="body" numberOfLines={3} style={styles.reply}>
        {entry.reply}
      </Text>
    </Pressable>
  );
}

export default function History() {
  const insets = useSafeAreaInsets();
  const queryClient = useQueryClient();

  const { data, isPending, isRefetching, refetch } = useQuery({
    queryKey: ['history'],
    queryFn: listHistory,
  });

  const wipe = useMutation({
    mutationFn: clearHistory,
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['history'] }),
  });

  const onRefresh = useCallback(() => void refetch(), [refetch]);
  const entries = data ?? [];

  return (
    <Screen padded={false}>
      <View style={styles.header}>
        <View style={styles.headerText}>
          <Text variant="title">History</Text>
          <Text variant="micro" tone="muted">
            {entries.length === 0
              ? 'Stored on this device only'
              : `${entries.length} kept on this device`}
          </Text>
        </View>

        {entries.length > 0 ? (
          <Pressable
            accessibilityRole="button"
            accessibilityLabel="Clear all history"
            hitSlop={12}
            onPress={() => wipe.mutate()}
            disabled={wipe.isPending}
          >
            <Text variant="caption" tone="danger">
              Clear
            </Text>
          </Pressable>
        ) : null}
      </View>

      {isPending ? (
        <View style={styles.center}>
          <ActivityIndicator color={palette.accent} />
        </View>
      ) : (
        <FlatList
          data={entries}
          keyExtractor={(entry) => entry.id}
          renderItem={({ item }) => <HistoryRow entry={item} />}
          contentContainerStyle={[
            styles.listContent,
            { paddingBottom: insets.bottom + spacing.lg },
            entries.length === 0 && styles.listEmpty,
          ]}
          refreshing={isRefetching}
          onRefresh={onRefresh}
          ListEmptyComponent={
            <View style={styles.center}>
              <Text variant="body" tone="muted" style={styles.emptyText}>
                Nothing has been said yet.
              </Text>
            </View>
          }
        />
      )}
    </Screen>
  );
}

const styles = StyleSheet.create({
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: spacing.lg,
    paddingBottom: spacing.md,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: palette.hairline,
  },
  headerText: { gap: spacing.xs },
  listContent: { padding: spacing.lg, gap: spacing.md },
  listEmpty: { flexGrow: 1 },
  center: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  emptyText: { textAlign: 'center' },
  row: {
    backgroundColor: palette.surface,
    borderRadius: radius.lg,
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: palette.hairline,
    padding: spacing.lg,
    gap: spacing.xs,
  },
  rowPressed: { opacity: 0.8 },
  rowHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: spacing.xs,
  },
  reply: { marginTop: spacing.xs },
});
